#!/bin/bash
cd ~
python3 -m http.server 8080
