===================================================================
  GATEWAY_PROXY  -  LSB Steganography Detection Lab
===================================================================
TASK: Detect steganography in WAV files from fileserver (10.0.0.10)

STEP 1 - Download WAV files:
  wget http://10.0.0.10:8080/lofi_morning.wav
  wget http://10.0.0.10:8080/lofi_evening.wav
  wget http://10.0.0.10:8080/lofi_study.wav
  wget http://10.0.0.10:8080/lofi_chill.wav
  wget http://10.0.0.10:8080/noisy_radio.wav

STEP 2 - Analyze each file:
  python3 icap_scrubber.py lofi_morning.wav
  python3 icap_scrubber.py lofi_evening.wav
  python3 icap_scrubber.py lofi_study.wav
  python3 icap_scrubber.py lofi_chill.wav
  python3 icap_scrubber.py noisy_radio.wav

STEP 3 - Check results:
  cat ~/findings.txt
  ls -lh ~/sanitized.wav

GRADING CRITERIA:
  [x] findings.txt contains WAV_ANALYZED
  [x] findings.txt contains LSB_DETECTED
  [x] sanitized.wav exists and is non-empty
  [x] bash_history contains icap_scrubber.py
===================================================================
