#!/usr/bin/env python3
"""
icap_scrubber.py - WAV Steganography Detector & Sanitizer
Usage: python3 icap_scrubber.py <file.wav>
Output: ~/findings.txt, ~/sanitized.wav
"""
import sys, os, wave, io, math
from collections import Counter

FINDINGS  = os.path.expanduser("~/findings.txt")
SANITIZED = os.path.expanduser("~/sanitized.wav")
KEYWORDS  = ["C2=","TOKEN=","powershell","http","cmd","bash","exec"]

def load_wav(path):
    with wave.open(path,"rb") as f:
        p = f.getparams()
        r = bytearray(f.readframes(f.getnframes()))
    return r, p

def entropy(raw):
    cnt = Counter(raw); n = len(raw)
    return -sum((c/n)*math.log2(c/n) for c in cnt.values() if c)

def lsb_chi(raw):
    lsbs = [b&1 for b in raw]; n = len(lsbs)
    z = lsbs.count(0); e = n/2
    return z/n*100, (n-z)/n*100, ((z-e)**2+(n-z-e)**2)/e

def lower4_chi(raw):
    from collections import Counter as C
    vals = [b&0x0F for b in raw]; cnt = C(vals); e = len(vals)/16
    return sum((cnt.get(v,0)-e)**2/e for v in range(16))

def extract_text(raw, nb=4096):
    bits = "".join(str(b&1) for b in raw[:nb])
    out = []
    for i in range(0,len(bits)-7,8):
        v = int(bits[i:i+8],2)
        out.append(chr(v) if 32<=v<=126 else ("." if v==0 else "?"))
    return "".join(out)

def sanitize(raw, params, path):
    clean = bytearray(b&0xFE for b in raw)
    buf = io.BytesIO()
    with wave.open(buf,"wb") as f:
        f.setparams(params); f.writeframes(bytes(clean))
    with open(path,"wb") as f: f.write(buf.getvalue())

def analyze(path):
    print(f"\n{'='*60}")
    print(f"  WAV ANALYZER  |  {path}")
    print(f"{'='*60}")

    raw, params = load_wav(path)
    print(f"  Size: {len(raw):,} bytes | {params.framerate}Hz | {params.sampwidth*8}-bit")

    detected = False; evidence = []

    ent = entropy(raw)
    print(f"\n  [Entropy]  {ent:.4f} bits/byte", end="  ")
    if ent < 7.5:
        print("<-- SUSPICIOUS"); evidence.append("LOW_ENTROPY"); detected = True
    else: print("(normal)")

    z,o,chi = lsb_chi(raw)
    print(f"\n  [LSB] 0:{z:.2f}%  1:{o:.2f}%  chi2={chi:.2f}", end="  ")
    if chi < 10:
        print("<-- VERY UNIFORM (stego!)"); evidence.append("LSB_CHI2_LOW"); detected = True
    elif chi < 100:
        print("<-- Fairly uniform"); evidence.append("LSB_FAIRLY_UNIFORM")
    else: print("(natural)")

    chi4 = lower4_chi(raw)
    print(f"\n  [4bit chi2] {chi4:.2f}", end="  ")
    if chi4 < 80:
        print("<-- 4-bit stego!"); evidence.append("4BIT_CHI2"); detected = True
    else: print("(normal)")

    text = extract_text(raw)
    pr = sum(1 for c in text if c not in ".?")/max(len(text),1)
    kw = [k for k in KEYWORDS if k.lower() in text.lower()]
    print(f"\n  [LSB text] '{text[:150]}'")
    print(f"  Printable: {pr:.1%}", end="  ")
    if kw:
        print(f"<-- KEYWORDS: {kw}"); evidence.append(f"KEYWORDS:{kw}"); detected = True
    elif pr > 0.70:
        print("<-- High printable"); evidence.append("HIGH_PRINTABLE"); detected = True
    else: print("(no match)")

    print(f"\n{'='*60}")
    print(f"  VERDICT: {'*** LSB DETECTED ***' if detected else 'CLEAN'}")
    print(f"{'='*60}")

    with open(FINDINGS, "a") as f:
        f.write(f"\n=== {os.path.basename(path)} ===\n")
        f.write("WAV_ANALYZED\n")
        if detected:
            f.write("LSB_DETECTED\n")
            for e in evidence: f.write(f"  {e}\n")
        else:
            f.write("CLEAN\n")

    print(f"  [+] Findings -> {FINDINGS}")

    if detected:
        sanitize(raw, params, SANITIZED)
        print(f"  [+] Sanitized -> {SANITIZED} ({os.path.getsize(SANITIZED):,} bytes)")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 icap_scrubber.py <file.wav>")
        print("  e.g. python3 icap_scrubber.py lofi_lsb1.wav")
        sys.exit(1)
    t = sys.argv[1]
    if not os.path.exists(t):
        print(f"[ERROR] File not found: {t}"); sys.exit(1)
    analyze(t)
